# PTSD Facial-Affect Screening

A research pipeline that turns short video clips of a person reacting to
visual stimuli into **FACS-inspired Action Unit (AU) features** and produces a
PTSD-risk **screening score**. Built around OpenCV + MediaPipe for facial
landmark tracking, with a temporal 1D-CNN classifier (PyTorch) and a
gradient-boosting baseline (scikit-learn).

> **This is a screening-support / research tool — not a medical device.**
> It does not diagnose anyone. Any output must be interpreted by a qualified
> clinician alongside validated instruments. See
> [`docs/MODEL_CARD.md`](docs/MODEL_CARD.md) and
> [`docs/DATA_PRIVACY.md`](docs/DATA_PRIVACY.md).

---

## Why this exists

Affective phenomenology in PTSD is partly visible on the face: blunted
positive affect, sustained periocular tension, negative valence, and
exaggerated startle responses to stimuli. Trained clinicians read these cues;
the goal here is a **reproducible, auditable pipeline** that quantifies them
from video as a *second pair of eyes* for screening — never as an autonomous
decision-maker.

The design is grounded in the Facial Action Coding System (FACS): instead of
learning opaque pixel features, the pipeline first computes interpretable
Action Units (e.g. *AU7 lid tightener*, *AU12 lip-corner puller*) from facial
geometry, then models their **temporal dynamics**. This keeps the features
clinically legible and the failure modes inspectable.

---

## What's in the box

```
src/ptsd_screening/
  landmarks.py      OpenCV frame iterator + MediaPipe FaceLandmarker (478 pts)
  action_units.py   478 landmarks -> 8 FACS-grounded Action Units (geometry)
  features.py       interpolation, smoothing, resampling, standardisation,
                    50-dim aggregate feature vector
  synthetic.py      class-conditional SYNTHETIC AU generator (no real data)
  dataset.py        manifest loading + subject-aware splitting (no leakage)
  model_cnn.py      TemporalAUNet — 1D-CNN over AU sequences (PyTorch)
  model_baseline.py HistGradientBoosting on aggregate features (sklearn)
  evaluate.py       metrics + FPR-budget operating-point selection
  train.py          training entrypoint (writes a reproducible run dir)
  predict.py        single-clip inference -> calibrated risk band
  config.py         one typed, YAML-driven config object
  utils.py          seeding, logging, run fingerprinting
scripts/            one-command demo, demo-data + model-download helpers
tests/              22 unit tests (pytest)
docs/               methodology, model card, data-privacy notes
```

### Pipeline at a glance

```
video.mp4
   │  OpenCV decode (frame stride, quality gating)
   ▼
478 facial landmarks per frame            (MediaPipe FaceLandmarker)
   │  align + inter-ocular scale normalisation (pose/scale invariant)
   ▼
8 Action Units per frame                  (FACS-grounded geometry)
   │  interpolate gaps · smooth jitter · resample to fixed length · z-score
   ▼
AU sequence  (T × 8)   ──►  Temporal 1D-CNN        (headline model)
        │                       OR
        └── 50-dim aggregate ──►  GBDT baseline     (no heavy deps)
   ▼
P(ptsd_risk)  ──►  threshold chosen by FPR budget  ──►  risk band
```

### The 8 Action Units

| Channel | Action Unit | Reads as |
|---|---|---|
| `AU1_2_brow_raise`     | Inner+outer brow raiser | orienting / startle |
| `AU4_brow_knit`        | Brow lowerer            | negative valence, tension |
| `AU6_cheek_raise`      | Cheek raiser            | Duchenne (genuine) smile |
| `AU7_lid_tighten`      | Lid tightener           | **periocular tension** |
| `AU12_lip_corner_pull` | Lip-corner puller       | positive affect / smile |
| `AU15_lip_corner_depress` | Lip-corner depressor | sadness / negative valence |
| `AU20_lip_stretch`     | Lip stretcher           | fear / startle |
| `AU25_26_jaw_drop`     | Lips part / jaw drop    | surprise, vocal/affective response |

Low cross-channel variance over a clip is summarised as a **flat-affect**
(blunted expressivity) signal; sustained `AU6/AU7` maps to the periocular
tension clinicians look for.

---

## Quickstart

Requires Python 3.10+.

```bash
# 1. Install (editable, src layout)
pip install -e .

# 2. Run the end-to-end demo on SYNTHETIC data (no GPU, no downloads)
python scripts/run_demo.py            # gradient-boosting baseline
python scripts/run_demo.py --model cnn   # 1D-CNN (needs torch)

# 3. Run the tests
pytest -q
```

The baseline demo needs only NumPy / pandas / scikit-learn / SciPy and runs in
seconds. The CNN path additionally needs `torch` (an optional dependency).

### Working with real video

```bash
# Download the MediaPipe FaceLandmarker model bundle (~3 MB)
python scripts/download_model.py

# Train from your own manifest (schema in data/README.md)
python -m ptsd_screening.train --manifest data/my_manifest.csv --model cnn

# Score a single clip
python -m ptsd_screening.predict --run runs/<run_dir> --video clip.mp4
```

---

## Demo results (synthetic data)

The numbers below come from `scripts/run_demo.py` on the **synthetic**
dataset (`seed = 1409`, gradient-boosting baseline). They exist to show the
pipeline is wired correctly end-to-end and lands at a *plausible* operating
point — **they are not clinical performance and say nothing about real
patients.**

| Split | AUC | Accuracy | Sensitivity | Specificity | FPR |
|---|---|---|---|---|---|
| Validation | 0.885 | 0.838 | 0.821 | 0.889 | 0.111 |
| Test       | 0.862 | 0.632 | 0.480 | 0.923 | 0.077 |

*240 synthetic clips across 120 synthetic subjects; subject-aware split
165 / 37 / 38. Decision threshold chosen on validation under a 0.20 FPR
budget, then applied unchanged to test.* The synthetic generator routes all
class signal through a single overlapping latent, which caps achievable AUC
well below 1.0 on purpose — see [`docs/METHODOLOGY.md`](docs/METHODOLOGY.md).
The validation→test drop in sensitivity is the expected behaviour of a fixed
operating point transferring to a small held-out set.

---

## Clinical context (the real-world work that motivated this)

> The section below describes the author's applied work in a clinical setting.
> **None of that data or those results are in this repository**, and the demo
> numbers above do **not** reproduce them. This is context only.

This pipeline is a clean-room reconstruction of a project originally built as a
volunteer ML engineer at a psychiatric clinical hospital (2024–2026). In that
setting the work involved:

- collecting and labelling **1,200+ video clips** of patients reacting to
  standardised stimulus images, with clinical ground truth anchored to
  **CAPS-5** assessments;
- FACS-based AU coding and identification of discriminative cues (periocular
  tension, blunted/flat-affect responses);
- tuning decision thresholds together with clinicians to **reduce the
  false-positive rate by ~18%** relative to an initial operating point;
- basic MLOps for reproducibility (data/model versioning, fixed seeds, run
  snapshots).

That clinical corpus is confidential patient data and is **never** distributed.
This public repository therefore ships the **methodology and full pipeline
code** plus a **synthetic** dataset so the system is runnable and auditable by
anyone, without exposing protected health information. See
[`docs/DATA_PRIVACY.md`](docs/DATA_PRIVACY.md).

---

## Design choices worth noting

- **Interpretable features first.** AUs are computed from normalised facial
  geometry (eye-aligned, inter-ocular scaled), so the model input is robust to
  head pose / camera distance and remains clinically legible.
- **Subject-aware splitting.** All clips from one subject stay in a single
  split (`GroupShuffleSplit`), so reported metrics aren't inflated by identity
  leakage. There's a unit test guarding this.
- **FPR as the headline operating constraint.** A screening tool that cries
  wolf erodes trust, so the threshold is chosen as the lowest value meeting an
  FPR budget on validation — mirroring how thresholds were tuned with
  clinicians in the original project.
- **Reproducibility by construction.** Every run writes its exact config, a
  data fingerprint, and a git commit to `runs/<timestamp>/`.
- **Optional heavy deps.** `torch` is imported lazily, so the whole repo
  (data, baseline, tests) runs without it.

---

## Limitations

- The included data is **synthetic**; the demo metrics are illustrative only.
- Facial-affect cues are **correlates**, not diagnostic criteria. PTSD is a
  clinical diagnosis; this tool can at most flag clips for human review.
- AU estimation from landmark geometry is an approximation of true FACS coding
  and is sensitive to occlusion, extreme pose, and low video quality (the
  pipeline rejects clips above a missing-frame threshold).
- Fairness across demographics, cameras, and recording conditions is **not**
  characterised here and must be validated before any real-world use.

---

## Project status & roadmap

Working: full landmark→AU→features→model→evaluation→inference path, both
models, reproducible runs, 22 passing unit tests, one-command synthetic demo.

Next: per-AU calibration curves, attention pooling over the temporal axis,
subject-level (rather than clip-level) aggregation, and a small Streamlit
viewer for AU traces.

A Russian-language version of this README can be added on request
(`README.ru.md`).

---

## License

[MIT](LICENSE). The synthetic data and code are free to use; there is no
clinical data in this repository to license.
