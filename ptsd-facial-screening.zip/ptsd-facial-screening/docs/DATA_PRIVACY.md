# Data Privacy

## Summary

**No clinical or personally identifiable data is contained in this
repository.** It ships only source code, documentation, and a synthetic
dataset that is generated on demand and represents no real person.

## The clinical corpus is not here — by design

The pipeline was originally developed against a corpus of patient videos in a
clinical setting. That corpus is **protected health information (PHI)**:
identifiable video of patients, linked to psychiatric assessment outcomes. It
is confidential and is **never** committed, uploaded, or otherwise
distributed. Nothing in this public repository can be used to reconstruct it.

What this means concretely:

- The repository contains **zero** patient frames, landmarks, AU traces, or
  labels derived from real people.
- The demo metrics in the README come from **synthetic** data only and do not
  describe any real population.
- The "clinical context" section of the README is a **description** of prior
  applied work, not a release of its data or its measured results.

## Synthetic data

`scripts/run_demo.py` and `scripts/make_demo_data.py` fabricate AU sequences
with class-conditional dynamics that loosely echo affect phenomenology from
the literature. These files:

- represent **no real individual**;
- are written under `data/synthetic/`, which is **git-ignored**;
- carry a `DATA_CARD.txt` on disk stating their synthetic origin;
- regenerate deterministically from a fixed seed.

## If you use this with real recordings

This code is research / screening-support software, not a medical device.
Before processing real human data you are responsible for:

- a lawful basis and ethics/IRB approval appropriate to your jurisdiction;
- informed consent covering recording, processing, and storage;
- keeping recordings and derived features **out of version control** (extend
  `.gitignore` to your data directories);
- storage encryption, access control, and retention/deletion policies for any
  PHI;
- data-minimisation — prefer storing derived AU sequences over raw video where
  the task allows, and avoid persisting identifiable frames.

When in doubt, treat facial video as highly sensitive biometric data and apply
the strictest applicable standard.
