# Data

**No real or clinical data is included in this repository.** The original
clinical video corpus is confidential patient data (see
[`../docs/DATA_PRIVACY.md`](../docs/DATA_PRIVACY.md)) and is never distributed.

What lives here:

- `manifest.example.csv` — a tiny example showing the manifest schema.
- `synthetic/` — generated on demand by `scripts/run_demo.py` /
  `scripts/make_demo_data.py`; **git-ignored** and clearly marked synthetic
  (each generated folder also contains a `DATA_CARD.txt`). Safe to delete; it
  regenerates deterministically from the seed.

## Manifest schema

Training and evaluation read a CSV manifest. Required columns:

| Column | Meaning |
|---|---|
| `clip_id`    | Unique id for the clip (used for filenames / logging). |
| `subject_id` | Person the clip belongs to. **Drives subject-aware splitting** — all clips from one subject stay in the same split, preventing identity leakage. |
| `label`      | `0` = control, `1` = ptsd_risk. |

Optional columns (provide at least one source of AU data):

| Column | Meaning |
|---|---|
| `video`   | Path to the raw video file. If set, landmarks→AUs are computed on the fly via MediaPipe. |
| `au_npy`  | Path to a pre-computed `(T, 8)` AU sequence saved as `.npy`. If set, it's loaded directly (skips video decoding). |

Paths may be absolute or relative to the manifest's directory. If both `video`
and `au_npy` are present, the cached `au_npy` is preferred.

## Bringing your own data

1. Organise clips so each file is a single subject reacting to stimuli.
2. Build a manifest matching the schema above (one row per clip).
3. Either point `video` at the files and let the pipeline extract AUs, or
   precompute AU sequences and reference them via `au_npy`.
4. Train:
   ```bash
   python -m ptsd_screening.train --manifest data/your_manifest.csv --model cnn
   ```

Keep any real recordings **outside** version control. The default
`.gitignore` already excludes `data/synthetic/`; extend it to cover your own
data directories before committing.
