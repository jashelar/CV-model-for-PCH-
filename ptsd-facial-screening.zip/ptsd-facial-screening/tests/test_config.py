"""Tests for config loading and dataset assembly / splitting."""

import numpy as np
import pytest
import yaml

from ptsd_screening.config import Config, load_config
from ptsd_screening.dataset import build_dataset, load_manifest, subject_aware_split
from ptsd_screening.synthetic import generate_dataset, save_dataset


def test_default_config():
    cfg = load_config()
    assert isinstance(cfg, Config)
    assert cfg.num_classes == 2
    assert cfg.features.sequence_length == 128


def test_yaml_overrides_nested_and_tuple(tmp_path):
    cfg_path = tmp_path / "c.yaml"
    cfg_path.write_text(
        yaml.safe_dump(
            {
                "seed": 42,
                "model": {"kind": "baseline", "cnn_channels": [16, 32]},
                "train": {"epochs": 3},
            }
        ),
        encoding="utf-8",
    )
    cfg = load_config(cfg_path)
    assert cfg.seed == 42
    assert cfg.model.kind == "baseline"
    assert cfg.model.cnn_channels == (16, 32)   # list coerced to tuple
    assert cfg.train.epochs == 3
    # Untouched defaults survive.
    assert cfg.features.sequence_length == 128


def test_missing_config_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        load_config(tmp_path / "nope.yaml")


def test_build_and_split_no_subject_leakage(tmp_path):
    cfg = load_config()
    cfg.features.sequence_length = 64  # keep the test fast
    save_dataset(generate_dataset(n_subjects=60, seed=9), tmp_path)
    df = load_manifest(tmp_path / "manifest.csv")
    data = build_dataset(df, cfg)

    assert data.sequences.shape[1:] == (64, 8)
    assert len(data) == len(df)

    tr, va, te = subject_aware_split(data, cfg.train.val_size, cfg.train.test_size, cfg.seed)
    s_tr = set(data.subjects[tr])
    s_va = set(data.subjects[va])
    s_te = set(data.subjects[te])
    assert s_tr.isdisjoint(s_va)
    assert s_tr.isdisjoint(s_te)
    assert s_va.isdisjoint(s_te)
    assert len(tr) + len(va) + len(te) == len(data)
