"""Tests for the synthetic data generator."""

import numpy as np
import pandas as pd

from ptsd_screening.action_units import NUM_AU
from ptsd_screening.dataset import REQUIRED_COLUMNS
from ptsd_screening.synthetic import generate_dataset, save_dataset


def test_generate_dataset_basic_properties():
    samples = generate_dataset(n_subjects=30, seed=7)
    assert len(samples) >= 30
    for s in samples:
        assert s.label in (0, 1)
        assert s.au_seq.ndim == 2 and s.au_seq.shape[1] == NUM_AU
        assert np.isfinite(s.au_seq).all()


def test_label_consistent_within_subject():
    samples = generate_dataset(n_subjects=40, seed=11)
    by_subject: dict[str, set] = {}
    for s in samples:
        by_subject.setdefault(s.subject_id, set()).add(s.label)
    assert all(len(labels) == 1 for labels in by_subject.values())


def test_classes_are_separable_but_overlapping():
    """Sanity: AU7 (lid tension) should differ on average across classes,
    yet classes must overlap (no trivial separation)."""
    samples = generate_dataset(n_subjects=120, seed=3)
    au7_pos = [s.au_seq[:, 3].mean() for s in samples if s.label == 1]
    au7_neg = [s.au_seq[:, 3].mean() for s in samples if s.label == 0]
    assert np.mean(au7_pos) > np.mean(au7_neg)          # signal exists
    assert min(au7_pos) < max(au7_neg)                  # but overlapping


def test_save_dataset_writes_valid_manifest(tmp_path):
    samples = generate_dataset(n_subjects=10, seed=5)
    manifest = save_dataset(samples, tmp_path)
    assert manifest.exists()
    df = pd.read_csv(manifest)
    for col in REQUIRED_COLUMNS:
        assert col in df.columns
    # AU files load with the right shape.
    first = np.load(tmp_path / df.iloc[0]["au_npy"])
    assert first.shape[1] == NUM_AU
    assert (tmp_path / "DATA_CARD.txt").exists()
