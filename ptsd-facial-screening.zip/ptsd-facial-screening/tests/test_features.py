"""Tests for temporal feature engineering."""

import numpy as np

from ptsd_screening.action_units import NUM_AU
from ptsd_screening.features import (
    Standardizer,
    aggregate_feature_names,
    aggregate_features,
    interpolate_missing,
    process_sequence,
    resample,
    smooth,
)


def test_interpolate_missing_fills_and_reports_fraction():
    seq = np.arange(20, dtype=float).reshape(10, 2)
    seq[3] = np.nan
    seq[7] = np.nan
    filled, frac = interpolate_missing(seq)
    assert np.isfinite(filled).all()
    assert abs(frac - 0.2) < 1e-9
    # Linear interpolation recovers the underlying ramp.
    assert np.allclose(filled[3], [6.0, 7.0], atol=1e-9)


def test_resample_changes_length_preserves_endpoints():
    seq = np.linspace(0, 1, 50).reshape(50, 1)
    out = resample(seq, 128)
    assert out.shape == (128, 1)
    assert np.isclose(out[0, 0], 0.0) and np.isclose(out[-1, 0], 1.0)


def test_smooth_reduces_noise_variance():
    rng = np.random.default_rng(0)
    clean = np.sin(np.linspace(0, 6, 200)).reshape(200, 1)
    noisy = clean + rng.normal(0, 0.5, clean.shape)
    out = smooth(noisy, window=9)
    assert out.shape == noisy.shape
    assert out.var() < noisy.var()


def test_process_sequence_output_shape():
    rng = np.random.default_rng(1)
    seq = rng.normal(size=(73, NUM_AU))
    seq[5] = np.nan
    fixed, missing = process_sequence(seq, sequence_length=128, smoothing_window=5)
    assert fixed.shape == (128, NUM_AU)
    assert fixed.dtype == np.float32
    assert 0.0 <= missing < 0.1


def test_aggregate_features_length_matches_names():
    seq = np.random.default_rng(2).normal(size=(120, NUM_AU))
    feats = aggregate_features(seq)
    names = aggregate_feature_names()
    assert feats.shape == (len(names),)
    assert len(names) == NUM_AU * 6 + 2


def test_standardizer_roundtrip_and_zscore():
    x = np.random.default_rng(3).normal(5, 3, size=(200, 7))
    scaler = Standardizer().fit(x)
    z = scaler.transform(x)
    assert np.allclose(z.mean(axis=0), 0, atol=1e-6)
    assert np.allclose(z.std(axis=0), 1, atol=1e-6)

    restored = Standardizer.from_state_dict(scaler.state_dict())
    assert np.allclose(restored.transform(x), z)
