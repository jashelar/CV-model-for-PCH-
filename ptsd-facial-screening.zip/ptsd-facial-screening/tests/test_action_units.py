"""Tests for the FACS Action Unit geometry."""

import numpy as np
import pytest

from ptsd_screening.action_units import (
    AU_NAMES,
    LEFT_BROW_MID,
    LEFT_EYE,
    LIP_CORNER_LEFT,
    LIP_CORNER_RIGHT,
    LIP_INNER_BOTTOM,
    NUM_AU,
    RIGHT_BROW_MID,
    RIGHT_EYE,
    compute_action_units,
    compute_au_sequence,
)

# AU channel positions for readable assertions
IDX = {name: i for i, name in enumerate(AU_NAMES)}


def make_neutral_face() -> np.ndarray:
    """A minimal, anatomically plausible neutral face (478, 3).

    Only the landmarks used by the AU code are placed meaningfully; the rest
    are finite filler. Coordinate frame: x right, y down (image convention).
    """
    pts = np.zeros((478, 3), dtype=np.float64)

    def set_xy(i, x, y):
        pts[i, 0] = x
        pts[i, 1] = y

    # Eyes (inner corners define the 1-unit inter-ocular reference)
    set_xy(33, -0.90, 0.00); set_xy(160, -0.78, -0.12); set_xy(158, -0.62, -0.12)
    set_xy(133, -0.50, 0.00); set_xy(153, -0.62, 0.12); set_xy(144, -0.78, 0.12)
    set_xy(362, 0.50, 0.00); set_xy(385, 0.62, -0.12); set_xy(387, 0.78, -0.12)
    set_xy(263, 0.90, 0.00); set_xy(373, 0.78, 0.12); set_xy(380, 0.62, 0.12)
    # Brows
    set_xy(105, -0.70, -0.35); set_xy(334, 0.70, -0.35)
    set_xy(107, -0.30, -0.33); set_xy(336, 0.30, -0.33)
    # Lower lids + cheeks
    set_xy(145, -0.70, 0.12); set_xy(374, 0.70, 0.12)
    set_xy(50, -0.70, 0.60); set_xy(280, 0.70, 0.60)
    # Mouth
    set_xy(61, -0.50, 1.30); set_xy(291, 0.50, 1.30)
    set_xy(13, 0.00, 1.25); set_xy(14, 0.00, 1.35)
    return pts


def test_neutral_shape_and_finite():
    au = compute_action_units(make_neutral_face())
    assert au.shape == (NUM_AU,)
    assert np.isfinite(au).all()


def test_nan_frame_returns_nan_vector():
    face = make_neutral_face()
    face[10, 0] = np.nan
    au = compute_action_units(face)
    assert au.shape == (NUM_AU,)
    assert np.isnan(au).all()


def test_brow_raise_increases_au1_2():
    base = compute_action_units(make_neutral_face())
    face = make_neutral_face()
    face[RIGHT_BROW_MID, 1] -= 0.15  # move brows up (smaller y)
    face[LEFT_BROW_MID, 1] -= 0.15
    raised = compute_action_units(face)
    assert raised[IDX["AU1_2_brow_raise"]] > base[IDX["AU1_2_brow_raise"]]


def test_mouth_open_increases_jaw_drop():
    base = compute_action_units(make_neutral_face())
    face = make_neutral_face()
    face[LIP_INNER_BOTTOM, 1] += 0.20  # drop lower lip
    opened = compute_action_units(face)
    assert opened[IDX["AU25_26_jaw_drop"]] > base[IDX["AU25_26_jaw_drop"]]


def test_smile_increases_pull_not_depress():
    base = compute_action_units(make_neutral_face())
    face = make_neutral_face()
    face[LIP_CORNER_RIGHT, 1] -= 0.20  # corners up
    face[LIP_CORNER_LEFT, 1] -= 0.20
    smile = compute_action_units(face)
    assert smile[IDX["AU12_lip_corner_pull"]] > base[IDX["AU12_lip_corner_pull"]]
    assert smile[IDX["AU15_lip_corner_depress"]] == 0.0


def test_lid_tightening_increases_au7():
    base = compute_action_units(make_neutral_face())
    face = make_neutral_face()
    # Squeeze the right eye vertically (top lids down, bottom lids up).
    for i in (160, 158):
        face[i, 1] += 0.08
    for i in (153, 144):
        face[i, 1] -= 0.08
    tight = compute_action_units(face)
    assert tight[IDX["AU7_lid_tighten"]] > base[IDX["AU7_lid_tighten"]]


def test_similarity_transform_invariance():
    """AUs must be invariant to rotation + uniform scale + translation."""
    face = make_neutral_face()
    base = compute_action_units(face)

    theta = np.deg2rad(17.0)
    rot = np.array([[np.cos(theta), -np.sin(theta)], [np.sin(theta), np.cos(theta)]])
    scale = 2.3
    shift = np.array([0.4, -0.9])

    moved = face.copy()
    moved[:, :2] = (face[:, :2] @ rot.T) * scale + shift
    transformed = compute_action_units(moved)

    assert np.allclose(base, transformed, atol=1e-4), np.abs(base - transformed).max()


def test_sequence_masks_invalid_frames():
    face = make_neutral_face()
    seq = np.stack([face, face, face])
    mask = np.array([True, False, True])
    au_seq = compute_au_sequence(seq, mask)
    assert au_seq.shape == (3, NUM_AU)
    assert np.isfinite(au_seq[0]).all()
    assert np.isnan(au_seq[1]).all()
    assert np.isfinite(au_seq[2]).all()
