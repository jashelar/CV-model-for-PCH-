"""FACS-inspired Action Unit (AU) features from FaceMesh landmarks.

This module is the domain core. It converts a frame of 468/478 MediaPipe
FaceMesh landmarks into eight interpretable, FACS-grounded Action Unit
intensities. The choice of AUs is deliberate for affect screening:

* AU1+2  brow raise        -- surprise / hypervigilant scanning
* AU4    brow knit         -- corrugator, distress / concentration
* AU6    cheek raise       -- Duchenne marker (genuine vs. social affect)
* AU7    lid tightening    -- orbicularis oculi tension (a key screening cue)
* AU12   lip-corner pull   -- positive affect
* AU15   lip-corner depress-- sadness
* AU20   lip stretch       -- fear / startle
* AU25/26 jaw drop         -- mouth opening, lips parting

Each frame is first aligned to a canonical pose (translate to the inner-eye
midpoint, rotate so the eye line is horizontal, scale by the inter-ocular
distance). This makes the features invariant to in-plane head roll, face
size and camera distance. Reduced *variance* of these channels across a
clip is itself informative -- it corresponds to blunted / flat affect.

References
----------
Ekman & Friesen, Facial Action Coding System (FACS).
Soukupova & Cech (2016), eye aspect ratio for blink detection.
Lugaresi et al. (2019), MediaPipe.
"""

from __future__ import annotations

import numpy as np

# --------------------------------------------------------------------------- #
# Canonical MediaPipe FaceMesh landmark indices
# --------------------------------------------------------------------------- #
# Eyes: 6-point sets ordered for the eye-aspect-ratio formula
#   [outer, top1, top2, inner, bottom2, bottom1]
RIGHT_EYE = (33, 160, 158, 133, 153, 144)
LEFT_EYE = (362, 385, 387, 263, 373, 380)

# Inner eye corners (medial canthi) -- anatomically stable, used as the
# normalisation / alignment reference.
RIGHT_EYE_INNER = 133
LEFT_EYE_INNER = 362

# Eyebrows: mid-arch and inner points
RIGHT_BROW_MID = 105
LEFT_BROW_MID = 334
RIGHT_BROW_INNER = 107
LEFT_BROW_INNER = 336

# Lower eyelid centre and cheek apex (for AU6 cheek raise)
RIGHT_LOWER_LID = 145
LEFT_LOWER_LID = 374
RIGHT_CHEEK = 50
LEFT_CHEEK = 280

# Mouth
LIP_CORNER_RIGHT = 61
LIP_CORNER_LEFT = 291
LIP_INNER_TOP = 13
LIP_INNER_BOTTOM = 14

AU_NAMES: tuple[str, ...] = (
    "AU1_2_brow_raise",
    "AU4_brow_knit",
    "AU6_cheek_raise",
    "AU7_lid_tighten",
    "AU12_lip_corner_pull",
    "AU15_lip_corner_depress",
    "AU20_lip_stretch",
    "AU25_26_jaw_drop",
)
NUM_AU = len(AU_NAMES)

_EPS = 1e-8


# --------------------------------------------------------------------------- #
# Geometry helpers
# --------------------------------------------------------------------------- #
def _align_and_scale(frame_xyz: np.ndarray) -> np.ndarray:
    """Return aligned, scale-normalised 2D landmarks ``(N, 2)``.

    The frame is translated so the inner-eye midpoint is the origin, rotated
    so the eye line is horizontal, and scaled by the inter-ocular distance.
    """
    xy = np.asarray(frame_xyz, dtype=np.float64)[:, :2]
    right_inner = xy[RIGHT_EYE_INNER]
    left_inner = xy[LEFT_EYE_INNER]
    origin = (right_inner + left_inner) / 2.0
    eye_vec = left_inner - right_inner
    scale = float(np.linalg.norm(eye_vec))
    if scale < _EPS:
        # Degenerate frame; return centred but unscaled to avoid blow-up.
        return xy - origin
    angle = np.arctan2(eye_vec[1], eye_vec[0])
    cos_a, sin_a = np.cos(-angle), np.sin(-angle)
    rot = np.array([[cos_a, -sin_a], [sin_a, cos_a]], dtype=np.float64)
    centred = xy - origin
    aligned = centred @ rot.T
    return aligned / scale


def _dist(pts: np.ndarray, a: int, b: int) -> float:
    return float(np.linalg.norm(pts[a] - pts[b]))


def _eye_aspect_ratio(pts: np.ndarray, eye: tuple[int, ...]) -> float:
    p0, p1, p2, p3, p4, p5 = eye
    vertical = _dist(pts, p1, p5) + _dist(pts, p2, p4)
    horizontal = 2.0 * _dist(pts, p0, p3)
    return vertical / (horizontal + _EPS)


# --------------------------------------------------------------------------- #
# Public API
# --------------------------------------------------------------------------- #
def compute_action_units(frame_xyz: np.ndarray) -> np.ndarray:
    """Compute the 8 AU intensities for a single frame.

    Parameters
    ----------
    frame_xyz:
        Array ``(N, 3)`` of landmark coordinates. May contain NaNs, in which
        case an all-NaN vector is returned (the frame is treated as missing).

    Returns
    -------
    np.ndarray
        Shape ``(NUM_AU,)`` float64. Larger values mean stronger activation;
        absolute offsets are removed downstream by per-subject/training
        standardisation, so only relative dynamics matter.
    """
    frame_xyz = np.asarray(frame_xyz, dtype=np.float64)
    if frame_xyz.ndim != 2 or frame_xyz.shape[1] < 2:
        raise ValueError("frame_xyz must have shape (N, >=2)")
    if not np.isfinite(frame_xyz[:, :2]).all():
        return np.full(NUM_AU, np.nan)

    p = _align_and_scale(frame_xyz)

    # Eye geometry
    ear_r = _eye_aspect_ratio(p, RIGHT_EYE)
    ear_l = _eye_aspect_ratio(p, LEFT_EYE)
    ear = 0.5 * (ear_r + ear_l)

    eye_center_r = p[list(RIGHT_EYE)].mean(axis=0)
    eye_center_l = p[list(LEFT_EYE)].mean(axis=0)

    # AU1+2  brow raise: brow above its eye centre (y increases downward,
    # so a larger (eye_y - brow_y) means the brow sits higher).
    brow_raise = 0.5 * (
        (eye_center_r[1] - p[RIGHT_BROW_MID][1])
        + (eye_center_l[1] - p[LEFT_BROW_MID][1])
    )

    # AU4 brow knit: inner brows drawn together -> smaller horizontal gap.
    inner_brow_gap = _dist(p, RIGHT_BROW_INNER, LEFT_BROW_INNER)
    brow_knit = -inner_brow_gap

    # AU6 cheek raise: cheek rises toward the lower eyelid -> smaller gap.
    cheek_gap = 0.5 * (_dist(p, RIGHT_LOWER_LID, RIGHT_CHEEK)
                       + _dist(p, LEFT_LOWER_LID, LEFT_CHEEK))
    cheek_raise = -cheek_gap

    # AU7 lid tightening: narrower palpebral aperture -> lower EAR.
    lid_tighten = -ear

    # Mouth geometry
    mouth_center_y = 0.5 * (p[LIP_INNER_TOP][1] + p[LIP_INNER_BOTTOM][1])
    corner_elev = 0.5 * (
        (mouth_center_y - p[LIP_CORNER_RIGHT][1])
        + (mouth_center_y - p[LIP_CORNER_LEFT][1])
    )
    # AU12 vs AU15: positive elevation -> corners up; negative -> down.
    lip_corner_pull = max(corner_elev, 0.0)
    lip_corner_depress = max(-corner_elev, 0.0)

    # AU20 lip stretch: mouth widening.
    lip_stretch = _dist(p, LIP_CORNER_RIGHT, LIP_CORNER_LEFT)

    # AU25/26 jaw drop: inner-lip vertical separation.
    jaw_drop = _dist(p, LIP_INNER_TOP, LIP_INNER_BOTTOM)

    return np.array(
        [
            brow_raise,
            brow_knit,
            cheek_raise,
            lid_tighten,
            lip_corner_pull,
            lip_corner_depress,
            lip_stretch,
            jaw_drop,
        ],
        dtype=np.float64,
    )


def compute_au_sequence(
    landmarks: np.ndarray, valid_mask: np.ndarray | None = None
) -> np.ndarray:
    """Compute AUs for every frame of a clip.

    Parameters
    ----------
    landmarks:
        Array ``(T, N, 3)``. Invalid frames may be all-NaN.
    valid_mask:
        Optional boolean ``(T,)``; ``False`` frames yield NaN AU rows
        regardless of their landmark contents.

    Returns
    -------
    np.ndarray
        Shape ``(T, NUM_AU)``; missing frames are NaN rows, to be handled
        (interpolated/rejected) by the feature pipeline.
    """
    landmarks = np.asarray(landmarks, dtype=np.float64)
    if landmarks.ndim != 3:
        raise ValueError("landmarks must have shape (T, N, 3)")
    n = landmarks.shape[0]
    out = np.empty((n, NUM_AU), dtype=np.float64)
    for t in range(n):
        if valid_mask is not None and not valid_mask[t]:
            out[t] = np.nan
        else:
            out[t] = compute_action_units(landmarks[t])
    return out
