"""Configuration handling.

A single YAML file drives the whole pipeline (extraction, feature
engineering, model, training). Keeping every knob in one typed object is
the backbone of reproducible experiments: the exact config used for a run
is snapshotted next to its metrics (see ``utils.start_run``).
"""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass
class ExtractionConfig:
    """How raw video becomes per-frame landmarks."""

    # Path to the MediaPipe FaceLandmarker model bundle (.task).
    # Downloadable with ``scripts/download_model.py``.
    model_path: str = "models/face_landmarker.task"
    # Sample every Nth frame (1 = every frame). Stimulus reactions are
    # short, so we keep temporal resolution fairly high.
    frame_stride: int = 1
    # Minimum detection confidence forwarded to MediaPipe.
    min_face_detection_confidence: float = 0.5
    min_tracking_confidence: float = 0.5
    # Frames where no face is found are linearly interpolated up to this
    # fraction of the clip; above it the clip is rejected as low quality.
    max_missing_fraction: float = 0.30


@dataclass
class FeatureConfig:
    """How landmark sequences become model inputs."""

    # Every clip is resampled to exactly this many timesteps so that
    # clips of different length share one tensor shape.
    sequence_length: int = 128
    # Light temporal smoothing (centred moving average) to suppress
    # single-frame landmark jitter. 1 disables it.
    smoothing_window: int = 5
    # z-score AU channels using statistics estimated on the training set.
    standardize: bool = True


@dataclass
class ModelConfig:
    """Model selection and 1D-CNN topology."""

    # "cnn" (temporal 1D-CNN, PyTorch) or "baseline" (sklearn GBDT).
    kind: str = "cnn"
    cnn_channels: tuple[int, ...] = (32, 64, 128)
    cnn_kernel_size: int = 5
    cnn_dropout: float = 0.3
    # Gradient-boosting baseline hyper-parameters.
    baseline_n_estimators: int = 300
    baseline_learning_rate: float = 0.05
    baseline_max_depth: int = 3


@dataclass
class TrainConfig:
    """Optimisation and evaluation settings."""

    epochs: int = 40
    batch_size: int = 16
    learning_rate: float = 1e-3
    weight_decay: float = 1e-4
    # Fraction of the data held out for validation / test.
    val_size: float = 0.15
    test_size: float = 0.15
    # Operating point: we pick the decision threshold on the validation
    # set as the lowest threshold whose FPR <= this budget. This mirrors
    # tuning thresholds with clinicians to keep false positives low.
    target_fpr: float = 0.20
    early_stopping_patience: int = 8


@dataclass
class Config:
    seed: int = 1409
    classes: tuple[str, ...] = ("control", "ptsd_risk")
    extraction: ExtractionConfig = field(default_factory=ExtractionConfig)
    features: FeatureConfig = field(default_factory=FeatureConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    train: TrainConfig = field(default_factory=TrainConfig)

    # ---- convenience -------------------------------------------------
    @property
    def num_classes(self) -> int:
        return len(self.classes)

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)


def _merge(base: dataclass, overrides: dict[str, Any]) -> Any:
    """Recursively overlay a dict onto a nested dataclass instance."""
    if not overrides:
        return base
    field_types = {f.name: f.type for f in dataclasses.fields(base)}
    values: dict[str, Any] = {}
    for f in dataclasses.fields(base):
        current = getattr(base, f.name)
        if f.name in overrides:
            ov = overrides[f.name]
            if dataclasses.is_dataclass(current) and isinstance(ov, dict):
                values[f.name] = _merge(current, ov)
            elif isinstance(current, tuple) and isinstance(ov, list):
                values[f.name] = tuple(ov)
            else:
                values[f.name] = ov
        else:
            values[f.name] = current
    _ = field_types  # kept for readability; types validated by dataclass
    return dataclasses.replace(base, **values)


def load_config(path: str | Path | None = None) -> Config:
    """Load a :class:`Config`, overlaying ``path`` (if given) on defaults."""
    cfg = Config()
    if path is None:
        return cfg
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    with path.open("r", encoding="utf-8") as fh:
        raw = yaml.safe_load(fh) or {}
    if not isinstance(raw, dict):
        raise ValueError(f"Config root must be a mapping, got {type(raw)}")
    return _merge(cfg, raw)
