"""Reproducibility and experiment-tracking utilities.

Every training run gets a timestamped directory under ``runs/`` containing a
snapshot of the exact config, the git commit, the data fingerprint and the
final metrics. That snapshot is what makes a result reproducible and is the
lightweight backbone of the project's "MLOps basics": config + data + model
are all versioned together, no external tracking server required.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import random
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np

from .config import Config


def set_seed(seed: int) -> None:
    """Seed Python, NumPy and (if installed) PyTorch for determinism."""
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    try:  # torch is optional
        import torch

        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    except Exception:
        pass


def setup_logging(level: int = logging.INFO) -> None:
    logging.basicConfig(
        level=level,
        format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
        datefmt="%H:%M:%S",
    )


def git_commit() -> str:
    try:
        out = subprocess.check_output(
            ["git", "rev-parse", "--short", "HEAD"], stderr=subprocess.DEVNULL
        )
        return out.decode().strip()
    except Exception:
        return "unknown"


def fingerprint(*arrays: np.ndarray) -> str:
    """Stable short hash of array contents -- a cheap data version id."""
    h = hashlib.sha256()
    for a in arrays:
        a = np.ascontiguousarray(a)
        h.update(str(a.shape).encode())
        h.update(a.tobytes())
    return h.hexdigest()[:12]


def start_run(cfg: Config, runs_root: str | Path = "runs", tag: str = "") -> Path:
    """Create and return a fresh timestamped run directory with metadata."""
    runs_root = Path(runs_root)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    name = f"{stamp}_{cfg.model.kind}" + (f"_{tag}" if tag else "")
    run_dir = runs_root / name
    run_dir.mkdir(parents=True, exist_ok=True)
    save_json(run_dir / "config.json", cfg.to_dict())
    save_json(
        run_dir / "metadata.json",
        {
            "created_utc": stamp,
            "git_commit": git_commit(),
            "model_kind": cfg.model.kind,
            "seed": cfg.seed,
        },
    )
    return run_dir


def save_json(path: str | Path, obj: Any) -> None:
    Path(path).write_text(json.dumps(obj, indent=2, default=str), encoding="utf-8")


def load_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))
