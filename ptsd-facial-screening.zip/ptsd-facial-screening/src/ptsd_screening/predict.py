"""Single-clip inference.

Usage
-----
    python -m ptsd_screening.predict --run runs/<run_dir> --video clip.mp4
    python -m ptsd_screening.predict --run runs/<run_dir> --au cached_au.npy

Loads a trained run, computes the screening score for one clip, and prints a
calibrated *band* (not a diagnosis). The output is decision-support only and
must be interpreted by a qualified clinician.
"""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

import numpy as np

from .action_units import NUM_AU, compute_au_sequence
from .config import load_config
from .features import aggregate_features, process_sequence
from .utils import load_json, setup_logging

logger = logging.getLogger("ptsd_screening.predict")

DISCLAIMER = (
    "Screening-support output only. This is NOT a diagnosis and must be "
    "reviewed by a qualified clinician alongside validated instruments."
)


def _band(score: float, threshold: float) -> str:
    if score < 0.5 * threshold:
        return "LOW"
    if score < threshold:
        return "BORDERLINE"
    if score < 0.5 * (1 + threshold):
        return "ELEVATED"
    return "HIGH"


def _au_for_input(args, cfg) -> np.ndarray:
    if args.au:
        arr = np.load(args.au)
        if arr.ndim != 2 or arr.shape[1] != NUM_AU:
            raise ValueError(f"AU file has shape {arr.shape}, expected (T,{NUM_AU})")
        return arr.astype(np.float64)
    from .landmarks import FaceLandmarkExtractor

    with FaceLandmarkExtractor(
        model_path=cfg.extraction.model_path,
        min_face_detection_confidence=cfg.extraction.min_face_detection_confidence,
        min_tracking_confidence=cfg.extraction.min_tracking_confidence,
    ) as extractor:
        landmarks, valid = extractor.extract_clip(
            args.video, stride=cfg.extraction.frame_stride
        )
    return compute_au_sequence(landmarks, valid)


def main(argv=None) -> dict:
    parser = argparse.ArgumentParser(description="Score one clip with a trained run.")
    parser.add_argument("--run", required=True, help="Path to a runs/<dir> directory.")
    parser.add_argument("--video", help="Path to a video clip.")
    parser.add_argument("--au", help="Path to a cached AU .npy sequence.")
    parser.add_argument("--config", default=None, help="Optional config override.")
    args = parser.parse_args(argv)
    setup_logging()

    if not args.video and not args.au:
        parser.error("Provide either --video or --au.")

    run_dir = Path(args.run)
    cfg = load_config(args.config) if args.config else load_config()
    # Prefer the config snapshot saved with the run.
    snap = run_dir / "config.json"
    if snap.exists():
        from .config import Config, _merge

        cfg = _merge(Config(), load_json(snap))
    results = load_json(run_dir / "metrics.json")
    threshold = float(results.get("chosen_threshold", 0.5))

    au_raw = _au_for_input(args, cfg)
    seq, missing = process_sequence(
        au_raw, cfg.features.sequence_length, cfg.features.smoothing_window
    )
    if missing > cfg.extraction.max_missing_fraction:
        logger.warning("Low-quality clip: %.0f%% frames missing.", 100 * missing)

    kind = results.get("model_kind", cfg.model.kind)
    if kind == "baseline":
        from .model_baseline import load_baseline, predict_baseline

        model = load_baseline(run_dir / "model.joblib")
        score = float(predict_baseline(model, aggregate_features(seq)[None, :])[0])
    else:
        from .model_cnn import load_cnn, predict_cnn

        model, scaler = load_cnn(cfg, run_dir / "model.pt")
        score = float(predict_cnn(model, scaler, seq[None, ...])[0])

    band = _band(score, threshold)
    out = {
        "score_ptsd_risk": round(score, 4),
        "threshold": round(threshold, 4),
        "band": band,
        "missing_fraction": round(missing, 4),
        "disclaimer": DISCLAIMER,
    }
    print(f"\nP(ptsd_risk) = {score:.3f}   band = {band}   (threshold {threshold:.3f})")
    print(DISCLAIMER + "\n")
    return out


if __name__ == "__main__":
    main()
