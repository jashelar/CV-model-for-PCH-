"""Temporal 1D-CNN over AU sequences (PyTorch).

The headline model. Each clip is a ``(L, NUM_AU)`` sequence; we treat the
AU channels as the convolution's input channels and convolve along time, so
the network learns short *temporal motifs* of facial dynamics (e.g. a brief
startle, a sustained periocular tension, a blunted vs. brisk smile onset)
rather than static frame appearance.

PyTorch is imported lazily so the rest of the package (extraction, features,
baseline, tests) works in environments without a deep-learning framework.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np

from .action_units import NUM_AU
from .config import Config
from .features import (
    Standardizer,
    apply_sequence_standardizer,
    fit_sequence_standardizer,
)


def _require_torch():
    try:
        import torch  # noqa: F401
    except Exception as exc:  # pragma: no cover
        raise ImportError(
            "PyTorch is required for the CNN model. Install with "
            "`pip install torch` or use --model baseline."
        ) from exc
    import torch

    return torch


def build_cnn(cfg: Config):
    """Construct the ``TemporalAUNet`` module from config."""
    torch = _require_torch()
    import torch.nn as nn

    class TemporalAUNet(nn.Module):
        def __init__(self, in_channels: int, channels, kernel_size: int, dropout: float, n_classes: int):
            super().__init__()
            blocks = []
            c_prev = in_channels
            for c in channels:
                blocks += [
                    nn.Conv1d(c_prev, c, kernel_size, padding=kernel_size // 2),
                    nn.BatchNorm1d(c),
                    nn.ReLU(inplace=True),
                    nn.MaxPool1d(2),
                    nn.Dropout(dropout),
                ]
                c_prev = c
            self.features = nn.Sequential(*blocks)
            self.head = nn.Sequential(
                nn.AdaptiveAvgPool1d(1),
                nn.Flatten(),
                nn.Linear(c_prev, c_prev // 2),
                nn.ReLU(inplace=True),
                nn.Dropout(dropout),
                nn.Linear(c_prev // 2, 1 if n_classes == 2 else n_classes),
            )

        def forward(self, x):  # x: (B, L, C) -> (B, C, L)
            x = x.transpose(1, 2)
            return self.head(self.features(x))

    return TemporalAUNet(
        in_channels=NUM_AU,
        channels=cfg.model.cnn_channels,
        kernel_size=cfg.model.cnn_kernel_size,
        dropout=cfg.model.cnn_dropout,
        n_classes=cfg.num_classes,
    )


def _to_loader(x: np.ndarray, y: np.ndarray, batch_size: int, shuffle: bool):
    torch = _require_torch()
    from torch.utils.data import DataLoader, TensorDataset

    ds = TensorDataset(
        torch.tensor(np.asarray(x), dtype=torch.float32),
        torch.tensor(np.asarray(y), dtype=torch.float32),
    )
    return DataLoader(ds, batch_size=batch_size, shuffle=shuffle)


def train_cnn(
    cfg: Config,
    seq_train: np.ndarray,
    y_train: np.ndarray,
    seq_val: np.ndarray,
    y_val: np.ndarray,
) -> tuple[object, Standardizer]:
    """Train ``TemporalAUNet`` with early stopping on validation AUC.

    Returns ``(best_model, sequence_standardizer)``. The standardiser is fit
    on training frames only and returned so inference matches training.
    """
    torch = _require_torch()
    import torch.nn as nn
    from sklearn.metrics import roc_auc_score

    scaler = fit_sequence_standardizer(list(seq_train))
    xtr = np.stack([apply_sequence_standardizer(s, scaler) for s in seq_train])
    xva = np.stack([apply_sequence_standardizer(s, scaler) for s in seq_val])

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = build_cnn(cfg).to(device)

    pos_weight = None
    n_pos = float((y_train == 1).sum())
    n_neg = float((y_train == 0).sum())
    if n_pos > 0:
        pos_weight = torch.tensor([n_neg / n_pos], dtype=torch.float32, device=device)
    criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
    optimiser = torch.optim.Adam(
        model.parameters(), lr=cfg.train.learning_rate, weight_decay=cfg.train.weight_decay
    )

    train_loader = _to_loader(xtr, y_train, cfg.train.batch_size, shuffle=True)

    best_auc, best_state, patience = -1.0, None, 0
    for epoch in range(cfg.train.epochs):
        model.train()
        for xb, yb in train_loader:
            xb, yb = xb.to(device), yb.to(device)
            optimiser.zero_grad()
            logits = model(xb).squeeze(-1)
            loss = criterion(logits, yb)
            loss.backward()
            optimiser.step()

        # validation AUC
        model.eval()
        with torch.no_grad():
            vlogits = model(torch.tensor(xva, dtype=torch.float32, device=device)).squeeze(-1)
            vscore = torch.sigmoid(vlogits).cpu().numpy()
        auc = roc_auc_score(y_val, vscore) if len(np.unique(y_val)) > 1 else 0.0
        if auc > best_auc:
            best_auc, patience = auc, 0
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        else:
            patience += 1
            if patience >= cfg.train.early_stopping_patience:
                break

    if best_state is not None:
        model.load_state_dict(best_state)
    return model, scaler


def predict_cnn(model, scaler: Standardizer, sequences: np.ndarray) -> np.ndarray:
    """Return P(ptsd_risk) for each clip."""
    torch = _require_torch()

    device = next(model.parameters()).device
    x = np.stack([apply_sequence_standardizer(s, scaler) for s in sequences])
    model.eval()
    with torch.no_grad():
        logits = model(torch.tensor(x, dtype=torch.float32, device=device)).squeeze(-1)
        return torch.sigmoid(logits).cpu().numpy()


def save_cnn(model, scaler: Standardizer, cfg: Config, path: str | Path) -> None:
    torch = _require_torch()

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "state_dict": model.state_dict(),
            "scaler": scaler.state_dict(),
            "config": cfg.to_dict(),
        },
        path,
    )


def load_cnn(cfg: Config, path: str | Path):
    torch = _require_torch()

    bundle = torch.load(path, map_location="cpu")
    model = build_cnn(cfg)
    model.load_state_dict(bundle["state_dict"])
    scaler = Standardizer.from_state_dict(bundle["scaler"])
    return model, scaler
