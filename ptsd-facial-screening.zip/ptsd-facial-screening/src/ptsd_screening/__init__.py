"""ptsd_screening
================

Facial-affect screening pipeline for PTSD risk stratification.

The package turns short video clips of a participant reacting to visual
stimuli into a fixed-length sequence of FACS-inspired Action Unit (AU)
features, and classifies the clip with either a temporal 1D-CNN
(``model_cnn``) or a gradient-boosting baseline (``model_baseline``).

This is a research / screening-support tool. It is **not** a medical
device and must never be used to make autonomous clinical decisions.
See ``docs/MODEL_CARD.md`` and ``docs/DATA_PRIVACY.md``.
"""

from __future__ import annotations

__version__ = "0.2.0"

from .action_units import AU_NAMES, compute_action_units
from .config import Config, load_config

__all__ = [
    "__version__",
    "Config",
    "load_config",
    "AU_NAMES",
    "compute_action_units",
]
