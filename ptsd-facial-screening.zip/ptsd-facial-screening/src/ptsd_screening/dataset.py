"""Dataset assembly and leakage-safe splitting.

A *manifest* CSV lists clips with columns:

    clip_id, subject_id, label, au_npy, video

``au_npy`` (precomputed AU sequence, relative to the manifest) is used if
present; otherwise AUs are extracted from ``video`` on the fly. Splits are
**subject-aware** (``GroupShuffleSplit`` on ``subject_id``) so no participant
appears in more than one split -- a non-negotiable requirement in clinical
ML, where per-subject leakage silently inflates metrics.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from .action_units import NUM_AU, compute_au_sequence
from .config import Config
from .features import aggregate_features, process_sequence

logger = logging.getLogger(__name__)

REQUIRED_COLUMNS = ("clip_id", "subject_id", "label")


@dataclass
class BuiltData:
    sequences: np.ndarray   # (N, L, NUM_AU) float32
    aggregates: np.ndarray  # (N, F) float64
    labels: np.ndarray      # (N,) int
    subjects: np.ndarray    # (N,) str
    clip_ids: np.ndarray    # (N,) str

    def __len__(self) -> int:
        return len(self.labels)


def load_manifest(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    df = pd.read_csv(path)
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Manifest {path} is missing columns: {missing}")
    df = df.copy()
    df["__manifest_dir__"] = str(path.parent)
    return df


def _load_au_for_row(row: pd.Series, cfg: Config, extractor=None) -> np.ndarray:
    base = Path(row["__manifest_dir__"])
    au_npy = str(row.get("au_npy", "") or "")
    if au_npy:
        arr = np.load(base / au_npy)
        if arr.ndim != 2 or arr.shape[1] != NUM_AU:
            raise ValueError(f"Cached AU {au_npy} has shape {arr.shape}, expected (T,{NUM_AU})")
        return arr.astype(np.float64)

    video = str(row.get("video", "") or "")
    if not video:
        raise ValueError(f"Clip {row['clip_id']} has neither au_npy nor video.")
    if extractor is None:
        from .landmarks import FaceLandmarkExtractor

        extractor = FaceLandmarkExtractor(
            model_path=cfg.extraction.model_path,
            min_face_detection_confidence=cfg.extraction.min_face_detection_confidence,
            min_tracking_confidence=cfg.extraction.min_tracking_confidence,
        )
    landmarks, valid = extractor.extract_clip(
        base / video, stride=cfg.extraction.frame_stride
    )
    return compute_au_sequence(landmarks, valid)


def build_dataset(df: pd.DataFrame, cfg: Config, extractor=None) -> BuiltData:
    """Process every clip into a fixed-length sequence + aggregate vector.

    Clips whose missing-frame fraction exceeds
    ``cfg.extraction.max_missing_fraction`` are dropped (logged).
    """
    seqs: list[np.ndarray] = []
    aggs: list[np.ndarray] = []
    labels: list[int] = []
    subjects: list[str] = []
    clip_ids: list[str] = []
    dropped = 0
    for _, row in df.iterrows():
        au_raw = _load_au_for_row(row, cfg, extractor)
        seq, missing = process_sequence(
            au_raw,
            sequence_length=cfg.features.sequence_length,
            smoothing_window=cfg.features.smoothing_window,
        )
        if missing > cfg.extraction.max_missing_fraction:
            dropped += 1
            logger.warning("Dropping %s: %.0f%% frames missing.", row["clip_id"], 100 * missing)
            continue
        seqs.append(seq)
        aggs.append(aggregate_features(seq))
        labels.append(int(row["label"]))
        subjects.append(str(row["subject_id"]))
        clip_ids.append(str(row["clip_id"]))
    if not seqs:
        raise RuntimeError("No clips survived quality filtering.")
    if dropped:
        logger.info("Dropped %d/%d clips for low quality.", dropped, len(df))
    return BuiltData(
        sequences=np.stack(seqs).astype(np.float32),
        aggregates=np.stack(aggs),
        labels=np.asarray(labels, dtype=int),
        subjects=np.asarray(subjects),
        clip_ids=np.asarray(clip_ids),
    )


def subject_aware_split(
    data: BuiltData, val_size: float, test_size: float, seed: int
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return index arrays ``(train_idx, val_idx, test_idx)``.

    Splitting is on unique ``subject_id`` so a subject's clips never straddle
    splits. Falls back to a deterministic group partition if scikit-learn is
    unavailable.
    """
    groups = data.subjects
    n = len(data)
    rng = np.random.default_rng(seed)

    try:
        from sklearn.model_selection import GroupShuffleSplit

        idx_all = np.arange(n)
        gss1 = GroupShuffleSplit(n_splits=1, test_size=test_size, random_state=seed)
        trainval_idx, test_idx = next(gss1.split(idx_all, groups=groups))
        rel_val = val_size / (1.0 - test_size)
        gss2 = GroupShuffleSplit(n_splits=1, test_size=rel_val, random_state=seed)
        tr_rel, val_rel = next(
            gss2.split(trainval_idx, groups=groups[trainval_idx])
        )
        train_idx = trainval_idx[tr_rel]
        val_idx = trainval_idx[val_rel]
        return np.sort(train_idx), np.sort(val_idx), np.sort(test_idx)
    except Exception:  # pragma: no cover - fallback path
        uniq = np.array(sorted(set(groups)))
        rng.shuffle(uniq)
        n_test = max(1, int(round(len(uniq) * test_size)))
        n_val = max(1, int(round(len(uniq) * val_size)))
        test_g = set(uniq[:n_test])
        val_g = set(uniq[n_test:n_test + n_val])
        train_idx = np.array([i for i in range(n) if groups[i] not in test_g | val_g])
        val_idx = np.array([i for i in range(n) if groups[i] in val_g])
        test_idx = np.array([i for i in range(n) if groups[i] in test_g])
        return train_idx, val_idx, test_idx
