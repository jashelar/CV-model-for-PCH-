"""Video decoding and facial-landmark extraction.

OpenCV decodes frames; MediaPipe FaceLandmarker turns each frame into a
``(478, 3)`` array of normalised landmark coordinates (x, y in [0, 1],
z relative depth). We support the modern *Tasks* API
(``mediapipe.tasks.python.vision.FaceLandmarker``) and fall back to the
legacy ``mp.solutions.face_mesh`` API so the code runs across MediaPipe
versions.

Only this module talks to MediaPipe/OpenCV; everything downstream works on
plain NumPy arrays, which keeps the rest of the package easy to unit-test.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Iterator

import numpy as np

logger = logging.getLogger(__name__)

# FaceLandmarker returns 478 points (468 face + 10 iris). The legacy
# face_mesh without refine_landmarks returns 468; AU geometry below only
# uses indices < 468, so both are compatible.
NUM_LANDMARKS = 478


# --------------------------------------------------------------------------- #
# Video decoding
# --------------------------------------------------------------------------- #
def iter_frames(video_path: str | Path, stride: int = 1) -> Iterator[np.ndarray]:
    """Yield RGB frames (H, W, 3) uint8 from a video file, every ``stride``-th."""
    import cv2

    video_path = str(video_path)
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise IOError(f"Could not open video: {video_path}")
    try:
        idx = 0
        while True:
            ok, frame_bgr = cap.read()
            if not ok:
                break
            if idx % stride == 0:
                yield cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
            idx += 1
    finally:
        cap.release()


# --------------------------------------------------------------------------- #
# Landmark extractor
# --------------------------------------------------------------------------- #
class FaceLandmarkExtractor:
    """Extract per-frame face landmarks for a whole clip.

    Parameters
    ----------
    model_path:
        Path to ``face_landmarker.task`` (Tasks API). Ignored by the legacy
        backend. Download with ``python scripts/download_model.py``.
    """

    def __init__(
        self,
        model_path: str | Path = "models/face_landmarker.task",
        min_face_detection_confidence: float = 0.5,
        min_tracking_confidence: float = 0.5,
    ) -> None:
        self.model_path = Path(model_path)
        self.min_face_detection_confidence = min_face_detection_confidence
        self.min_tracking_confidence = min_tracking_confidence
        self._backend = None  # lazily initialised
        self._kind: str | None = None

    # -- backend setup ----------------------------------------------------- #
    def _ensure_backend(self) -> None:
        if self._backend is not None:
            return
        try:
            self._init_tasks_backend()
            self._kind = "tasks"
            logger.info("Using MediaPipe Tasks FaceLandmarker.")
            return
        except Exception as exc:  # pragma: no cover - depends on install
            logger.warning("Tasks API unavailable (%s); trying legacy.", exc)
        self._init_legacy_backend()
        self._kind = "legacy"
        logger.info("Using legacy mediapipe.solutions.face_mesh.")

    def _init_tasks_backend(self) -> None:
        from mediapipe.tasks import python as mp_python
        from mediapipe.tasks.python import vision

        if not self.model_path.exists():
            raise FileNotFoundError(
                f"FaceLandmarker model not found at {self.model_path}. "
                "Run: python scripts/download_model.py"
            )
        options = vision.FaceLandmarkerOptions(
            base_options=mp_python.BaseOptions(model_asset_path=str(self.model_path)),
            running_mode=vision.RunningMode.VIDEO,
            num_faces=1,
            min_face_detection_confidence=self.min_face_detection_confidence,
            min_tracking_confidence=self.min_tracking_confidence,
        )
        self._backend = vision.FaceLandmarker.create_from_options(options)

    def _init_legacy_backend(self) -> None:  # pragma: no cover - version dependent
        import mediapipe as mp

        self._backend = mp.solutions.face_mesh.FaceMesh(
            static_image_mode=False,
            max_num_faces=1,
            refine_landmarks=True,
            min_detection_confidence=self.min_face_detection_confidence,
            min_tracking_confidence=self.min_tracking_confidence,
        )

    # -- per-frame inference ---------------------------------------------- #
    def _landmarks_from_frame(self, frame_rgb: np.ndarray, timestamp_ms: int) -> np.ndarray | None:
        self._ensure_backend()
        if self._kind == "tasks":
            import mediapipe as mp

            mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=frame_rgb)
            result = self._backend.detect_for_video(mp_image, timestamp_ms)
            faces = getattr(result, "face_landmarks", None)
            if not faces:
                return None
            pts = faces[0]
            return np.asarray([[p.x, p.y, p.z] for p in pts], dtype=np.float32)
        # legacy backend  # pragma: no cover
        result = self._backend.process(frame_rgb)
        if not getattr(result, "multi_face_landmarks", None):
            return None
        pts = result.multi_face_landmarks[0].landmark
        return np.asarray([[p.x, p.y, p.z] for p in pts], dtype=np.float32)

    # -- whole-clip API ---------------------------------------------------- #
    def extract_clip(
        self, video_path: str | Path, stride: int = 1, fps: float = 30.0
    ) -> tuple[np.ndarray, np.ndarray]:
        """Return ``(landmarks, valid_mask)`` for a clip.

        ``landmarks`` has shape ``(T, NUM_LANDMARKS, 3)`` with NaN rows where
        no face was detected; ``valid_mask`` is a boolean ``(T,)`` array.
        """
        seq: list[np.ndarray] = []
        mask: list[bool] = []
        dt_ms = 1000.0 / max(fps, 1e-6) * stride
        for i, frame in enumerate(iter_frames(video_path, stride=stride)):
            ts = int(round(i * dt_ms))
            lm = self._landmarks_from_frame(frame, ts)
            if lm is None:
                seq.append(np.full((NUM_LANDMARKS, 3), np.nan, dtype=np.float32))
                mask.append(False)
            else:
                # legacy without irises -> pad to NUM_LANDMARKS
                if lm.shape[0] < NUM_LANDMARKS:
                    pad = np.full((NUM_LANDMARKS - lm.shape[0], 3), np.nan, np.float32)
                    lm = np.vstack([lm, pad])
                seq.append(lm)
                mask.append(True)
        if not seq:
            raise IOError(f"No frames decoded from {video_path}")
        return np.stack(seq, axis=0), np.asarray(mask, dtype=bool)

    def close(self) -> None:
        if self._backend is not None and hasattr(self._backend, "close"):
            self._backend.close()
        self._backend = None

    def __enter__(self) -> "FaceLandmarkExtractor":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()
