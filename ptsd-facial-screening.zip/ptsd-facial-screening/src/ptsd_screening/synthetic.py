"""Synthetic data generator (NOT real patient data).

The clinical video corpus is confidential and is never distributed. To keep
the whole pipeline runnable and reproducible, this module fabricates AU
sequences with class-conditional dynamics that *loosely* mirror affect
phenomenology reported in the literature:

* ``control``   -- richer, more dynamic positive affect; relaxed periocular
  muscles; expressive responses to stimuli.
* ``ptsd_risk`` -- blunted positive affect (lower AU6/AU12 variance),
  sustained periocular tension (elevated AU7/AU4), more negative valence
  (AU15), and occasional startle spikes (AU1+2 / AU20).

The classes deliberately overlap, so a trained model lands at a realistic
(not perfect) operating point. Samples are grouped by subject so that
subject-aware splitting can be demonstrated. **None of this reflects any
real individual.**
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .action_units import AU_NAMES, NUM_AU

# Channel indices (must match AU_NAMES order)
_BROW_RAISE, _BROW_KNIT, _CHEEK, _LID, _PULL, _DEPRESS, _STRETCH, _JAW = range(NUM_AU)


@dataclass
class ClipSample:
    clip_id: str
    subject_id: str
    label: int  # 0 = control, 1 = ptsd_risk
    au_seq: np.ndarray  # (T, NUM_AU)


def _bump(t: np.ndarray, center: float, width: float, amp: float) -> np.ndarray:
    """A smooth Gaussian reaction bump over normalised time ``t`` in [0, 1]."""
    return amp * np.exp(-0.5 * ((t - center) / max(width, 1e-3)) ** 2)


def _simulate_clip(label: int, length: int, subj_offset: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """Simulate one AU sequence.

    Design note on *why* the task is non-trivial. All class-discriminative
    structure flows through a single scalar latent ``severity`` whose
    class-conditional distributions deliberately **overlap**:

        control   :  severity ~ N(0.25, 0.20)
        ptsd_risk :  severity ~ N(0.70, 0.20)        d' ~ 2.2

    Because every informative channel is a noisy function of this one latent
    (a label -> severity -> channels Markov chain), no amount of
    feature-combining can recover the class better than ``severity`` itself
    separates it. That analytically caps ROC-AUC at ~0.93, and the realized
    score sits below it (~0.80-0.87) once channels are observed through
    noise -- a realistic operating point rather than a giveaway AUC=1.0.

    A second latent, ``expressiveness``, is drawn **independently of the
    label** and drives the positive-affect bumps; it is pure nuisance and
    further blurs the boundary, mimicking benign inter-individual variation
    in how animated a face is.
    """
    t = np.linspace(0.0, 1.0, length)
    seq = np.zeros((length, NUM_AU), dtype=np.float64)

    # --- Latent factors (one draw per clip) ---------------------------------
    sev_mean = 0.70 if label == 1 else 0.25
    severity = rng.normal(sev_mean, 0.20)          # overlapping signal latent
    express = rng.normal(0.50, 0.22)               # label-independent nuisance

    # Slow baseline drift per channel + subject-level offset.
    for c in range(NUM_AU):
        drift = 0.05 * np.sin(2 * np.pi * (rng.uniform(0.3, 0.9)) * t + rng.uniform(0, 2 * np.pi))
        seq[:, c] += subj_offset[c] + drift

    # --- Sustained (tonic) channels: noisy functions of severity ------------
    # Periocular tension (AU7) and brow knit (AU4) rise with severity;
    # lip-corner depress (AU15, negative valence) too. Per-channel noise is
    # comparable to the signal so each channel alone is weak.
    seq[:, _LID] += 0.70 * severity + rng.normal(0.0, 0.14)
    seq[:, _BROW_KNIT] += 0.60 * severity + rng.normal(0.0, 0.14)
    seq[:, _DEPRESS] += 0.55 * severity + rng.normal(0.0, 0.13)

    # --- Phasic stimulus reactions ------------------------------------------
    n_events = rng.integers(2, 5)
    centers = np.sort(rng.uniform(0.1, 0.9, size=n_events))

    # Positive affect (smile AU12 + Duchenne cheek AU6) scales with
    # expressiveness but is *blunted* by severity. Orienting brow-raise and
    # jaw are mostly nuisance (driven by expressiveness).
    pull_gain = max(0.0, express - 0.55 * severity)
    cheek_gain = max(0.0, 0.9 * express - 0.45 * severity)
    for cen in centers:
        w = rng.uniform(0.03, 0.08)
        seq[:, _PULL] += _bump(t, cen, w, pull_gain * rng.uniform(0.7, 1.1))
        seq[:, _CHEEK] += _bump(t, cen, w, cheek_gain * rng.uniform(0.7, 1.1))
        seq[:, _BROW_RAISE] += _bump(t, cen, w, 0.7 * express * rng.uniform(0.7, 1.1))
        seq[:, _JAW] += _bump(t, cen, w, 0.5 * express * rng.uniform(0.6, 1.1))

    # Startle hyper-reactivity (AU1+2 / AU20) gets *more likely* with severity,
    # but the gate is stochastic so it overlaps across classes.
    startle_p = float(np.clip(0.15 + 0.40 * severity, 0.0, 0.9))
    for cen in centers:
        if rng.random() < startle_p:
            sw = rng.uniform(0.015, 0.035)
            amp = 0.30 + 0.50 * max(severity, 0.0)
            seq[:, _BROW_RAISE] += _bump(t, cen, sw, amp * rng.uniform(0.7, 1.1))
            seq[:, _STRETCH] += _bump(t, cen, sw, amp * rng.uniform(0.7, 1.1))

    # Per-frame sensor/landmark noise (substantial, to keep classes close).
    seq += rng.normal(0.0, 0.10, size=seq.shape)
    return seq


def generate_dataset(
    n_subjects: int = 120,
    clips_per_subject: tuple[int, int] = (1, 3),
    seq_len_range: tuple[int, int] = (90, 200),
    positive_rate: float = 0.45,
    seed: int = 1409,
) -> list[ClipSample]:
    """Generate a list of :class:`ClipSample`, grouped by subject."""
    rng = np.random.default_rng(seed)
    samples: list[ClipSample] = []
    for s in range(n_subjects):
        label = int(rng.random() < positive_rate)
        subj_id = f"subj_{s:04d}"
        # Subject-level AU offsets create within-subject correlation.
        subj_offset = rng.normal(0.0, 0.12, size=NUM_AU)
        n_clips = int(rng.integers(clips_per_subject[0], clips_per_subject[1] + 1))
        for k in range(n_clips):
            length = int(rng.integers(seq_len_range[0], seq_len_range[1] + 1))
            au = _simulate_clip(label, length, subj_offset, rng)
            samples.append(
                ClipSample(
                    clip_id=f"{subj_id}_clip{k}",
                    subject_id=subj_id,
                    label=label,
                    au_seq=au.astype(np.float32),
                )
            )
    rng.shuffle(samples)
    return samples


def save_dataset(samples: list[ClipSample], out_dir: str | Path) -> Path:
    """Persist AU sequences as ``.npy`` plus a ``manifest.csv``.

    Returns the manifest path. The manifest schema matches what
    :mod:`ptsd_screening.dataset` consumes (``au_npy`` column).
    """
    import pandas as pd

    out_dir = Path(out_dir)
    au_dir = out_dir / "au"
    au_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for smp in samples:
        rel = f"au/{smp.clip_id}.npy"
        np.save(out_dir / rel, smp.au_seq)
        rows.append(
            {
                "clip_id": smp.clip_id,
                "subject_id": smp.subject_id,
                "label": smp.label,
                "au_npy": rel,
                "video": "",
            }
        )
    manifest = out_dir / "manifest.csv"
    pd.DataFrame(rows, columns=["clip_id", "subject_id", "label", "au_npy", "video"]).to_csv(
        manifest, index=False
    )
    # Small data-card so the synthetic origin is unmistakable on disk.
    (out_dir / "DATA_CARD.txt").write_text(
        "SYNTHETIC DATA -- generated by ptsd_screening.synthetic.\n"
        "Does not represent any real person. For pipeline demos/tests only.\n"
        f"AU channel order: {', '.join(AU_NAMES)}\n",
        encoding="utf-8",
    )
    return manifest
