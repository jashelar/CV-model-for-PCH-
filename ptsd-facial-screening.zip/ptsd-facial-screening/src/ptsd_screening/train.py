"""Training entrypoint.

Usage
-----
    python -m ptsd_screening.train --manifest data/synthetic/manifest.csv \\
        --config config/default.yaml --model baseline

Builds the dataset, makes a subject-aware split, fits the chosen model,
selects the decision threshold on validation under the configured FPR
budget, evaluates on the held-out test split, and writes everything
(config, metadata, metrics, model) to a fresh ``runs/`` directory.
"""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

import numpy as np

from .config import load_config
from .dataset import build_dataset, load_manifest, subject_aware_split
from .evaluate import choose_threshold_for_fpr, compute_metrics
from .utils import fingerprint, save_json, set_seed, setup_logging, start_run

logger = logging.getLogger("ptsd_screening.train")


def parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Train the PTSD facial-screening model.")
    p.add_argument("--manifest", required=True, help="Path to dataset manifest CSV.")
    p.add_argument("--config", default=None, help="Path to YAML config.")
    p.add_argument("--model", choices=["cnn", "baseline"], default=None,
                   help="Override model kind from config.")
    p.add_argument("--runs-root", default="runs", help="Where to write run dirs.")
    p.add_argument("--tag", default="", help="Optional run name suffix.")
    return p.parse_args(argv)


def main(argv=None) -> dict:
    args = parse_args(argv)
    setup_logging()
    cfg = load_config(args.config)
    if args.model:
        cfg.model.kind = args.model
    set_seed(cfg.seed)

    logger.info("Loading manifest: %s", args.manifest)
    df = load_manifest(args.manifest)
    data = build_dataset(df, cfg)
    logger.info("Built %d clips across %d subjects.", len(data), len(set(data.subjects)))

    train_idx, val_idx, test_idx = subject_aware_split(
        data, cfg.train.val_size, cfg.train.test_size, cfg.seed
    )
    logger.info("Split sizes -> train=%d val=%d test=%d", len(train_idx), len(val_idx), len(test_idx))

    run_dir = start_run(cfg, runs_root=args.runs_root, tag=args.tag)
    data_fp = fingerprint(data.sequences, data.labels)
    logger.info("Run dir: %s | data fingerprint: %s", run_dir, data_fp)

    y = data.labels
    if cfg.model.kind == "baseline":
        from .model_baseline import predict_baseline, save_baseline, train_baseline

        model = train_baseline(
            cfg, data.aggregates[train_idx], y[train_idx],
            data.aggregates[val_idx], y[val_idx],
        )
        val_score = predict_baseline(model, data.aggregates[val_idx])
        test_score = predict_baseline(model, data.aggregates[test_idx])
        save_baseline(model, run_dir / "model.joblib")
    else:
        from .model_cnn import predict_cnn, save_cnn, train_cnn

        model, scaler = train_cnn(
            cfg, data.sequences[train_idx], y[train_idx],
            data.sequences[val_idx], y[val_idx],
        )
        val_score = predict_cnn(model, scaler, data.sequences[val_idx])
        test_score = predict_cnn(model, scaler, data.sequences[test_idx])
        save_cnn(model, scaler, cfg, run_dir / "model.pt")

    threshold = choose_threshold_for_fpr(y[val_idx], val_score, cfg.train.target_fpr)
    val_metrics = compute_metrics(y[val_idx], val_score, threshold)
    test_metrics = compute_metrics(y[test_idx], test_score, threshold)

    logger.info("VALIDATION  %s", val_metrics.summary())
    logger.info("TEST        %s", test_metrics.summary())

    results = {
        "model_kind": cfg.model.kind,
        "data_fingerprint": data_fp,
        "n_train": int(len(train_idx)),
        "n_val": int(len(val_idx)),
        "n_test": int(len(test_idx)),
        "target_fpr": cfg.train.target_fpr,
        "chosen_threshold": threshold,
        "validation": val_metrics.as_dict(),
        "test": test_metrics.as_dict(),
    }
    save_json(run_dir / "metrics.json", results)
    logger.info("Saved metrics + model to %s", run_dir)
    return results


if __name__ == "__main__":
    main()
