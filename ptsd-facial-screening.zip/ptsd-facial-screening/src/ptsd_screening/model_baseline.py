"""Gradient-boosting baseline over aggregated AU features.

A strong, fast classical baseline is the honest yardstick every deep model
should beat. We summarise each clip into a fixed-length statistics vector
(see ``features.aggregate_features``) and fit a histogram gradient-boosting
classifier inside a standardising pipeline.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np

from .config import Config


def build_baseline(cfg: Config):
    """Return an unfitted sklearn pipeline (StandardScaler -> HistGBDT)."""
    from sklearn.ensemble import HistGradientBoostingClassifier
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import StandardScaler

    clf = HistGradientBoostingClassifier(
        max_iter=cfg.model.baseline_n_estimators,
        learning_rate=cfg.model.baseline_learning_rate,
        max_depth=cfg.model.baseline_max_depth,
        l2_regularization=1.0,
        early_stopping=True,
        validation_fraction=0.15,
        random_state=cfg.seed,
    )
    return Pipeline([("scaler", StandardScaler()), ("clf", clf)])


def train_baseline(
    cfg: Config,
    x_train: np.ndarray,
    y_train: np.ndarray,
    x_val: np.ndarray | None = None,
    y_val: np.ndarray | None = None,
):
    """Fit and return the baseline pipeline. (val args kept for a uniform API.)"""
    model = build_baseline(cfg)
    model.fit(x_train, y_train)
    return model


def predict_baseline(model, x: np.ndarray) -> np.ndarray:
    """Return P(ptsd_risk) for each row."""
    proba = model.predict_proba(x)
    # positive class is label 1
    classes = list(model.classes_) if hasattr(model, "classes_") else [0, 1]
    pos = classes.index(1) if 1 in classes else proba.shape[1] - 1
    return proba[:, pos]


def save_baseline(model, path: str | Path) -> None:
    import joblib

    Path(path).parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, path)


def load_baseline(path: str | Path):
    import joblib

    return joblib.load(path)
