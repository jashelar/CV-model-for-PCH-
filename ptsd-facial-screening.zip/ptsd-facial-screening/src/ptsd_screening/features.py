"""Temporal feature engineering on AU sequences.

Turns a raw ``(T, NUM_AU)`` AU sequence (with possible missing frames) into
model-ready tensors:

* ``process_sequence`` -> a clean, fixed-length ``(L, NUM_AU)`` sequence for
  the temporal CNN.
* ``aggregate_features`` -> a fixed-length statistics vector for the
  gradient-boosting baseline (mean/std/min/max/slope/dynamics per channel
  plus two global expressivity scalars).

The standardiser is *fit on the training split only* and reused for
validation/test/inference, which is essential for honest evaluation.
"""

from __future__ import annotations

import numpy as np

from .action_units import AU_NAMES, NUM_AU


# --------------------------------------------------------------------------- #
# Cleaning
# --------------------------------------------------------------------------- #
def interpolate_missing(au_seq: np.ndarray) -> tuple[np.ndarray, float]:
    """Linearly interpolate NaN frames per channel.

    Returns ``(filled, missing_fraction)``. Leading/trailing gaps are filled
    by the nearest valid value (edge hold).
    """
    au_seq = np.asarray(au_seq, dtype=np.float64).copy()
    t = au_seq.shape[0]
    row_missing = np.isnan(au_seq).any(axis=1)
    missing_fraction = float(row_missing.mean()) if t else 1.0
    x = np.arange(t)
    for c in range(au_seq.shape[1]):
        col = au_seq[:, c]
        good = ~np.isnan(col)
        if good.sum() == 0:
            au_seq[:, c] = 0.0
        elif good.sum() < t:
            au_seq[:, c] = np.interp(x, x[good], col[good])
    return au_seq, missing_fraction


def smooth(au_seq: np.ndarray, window: int) -> np.ndarray:
    """Centred moving-average smoothing along time. ``window<=1`` is a no-op."""
    au_seq = np.asarray(au_seq, dtype=np.float64)
    if window <= 1 or au_seq.shape[0] <= 2:
        return au_seq
    window = min(window, au_seq.shape[0])
    if window % 2 == 0:  # keep it odd for a symmetric window
        window -= 1
    if window <= 1:
        return au_seq
    pad = window // 2
    kernel = np.ones(window) / window
    out = np.empty_like(au_seq)
    for c in range(au_seq.shape[1]):
        padded = np.pad(au_seq[:, c], pad, mode="edge")
        out[:, c] = np.convolve(padded, kernel, mode="valid")
    return out


def resample(au_seq: np.ndarray, length: int) -> np.ndarray:
    """Resample a sequence to exactly ``length`` timesteps by linear interp."""
    au_seq = np.asarray(au_seq, dtype=np.float64)
    t = au_seq.shape[0]
    if t == length:
        return au_seq
    if t == 1:
        return np.repeat(au_seq, length, axis=0)
    src = np.linspace(0.0, 1.0, t)
    dst = np.linspace(0.0, 1.0, length)
    out = np.empty((length, au_seq.shape[1]), dtype=np.float64)
    for c in range(au_seq.shape[1]):
        out[:, c] = np.interp(dst, src, au_seq[:, c])
    return out


def process_sequence(
    au_seq: np.ndarray, sequence_length: int = 128, smoothing_window: int = 5
) -> tuple[np.ndarray, float]:
    """Clean -> smooth -> resample. Returns ``(seq, missing_fraction)``."""
    filled, missing = interpolate_missing(au_seq)
    smoothed = smooth(filled, smoothing_window)
    fixed = resample(smoothed, sequence_length)
    return fixed.astype(np.float32), missing


# --------------------------------------------------------------------------- #
# Aggregation for the classical baseline
# --------------------------------------------------------------------------- #
_STATS = ("mean", "std", "min", "max", "slope", "dynamics")


def aggregate_feature_names() -> list[str]:
    names = [f"{au}__{stat}" for au in AU_NAMES for stat in _STATS]
    names += ["global__expressivity", "global__total_motion"]
    return names


def aggregate_features(seq: np.ndarray) -> np.ndarray:
    """Summarise a ``(T, NUM_AU)`` sequence into a fixed-length vector.

    Per channel: mean, std, min, max, linear-trend slope and ``dynamics``
    (mean absolute first difference). Two global scalars capture overall
    expressivity (mean of channel std-devs -- low => blunted/flat affect)
    and total motion. Channel order matches :data:`AU_NAMES`.
    """
    seq = np.asarray(seq, dtype=np.float64)
    if seq.ndim != 2 or seq.shape[1] != NUM_AU:
        raise ValueError(f"expected (T, {NUM_AU}) sequence, got {seq.shape}")
    t = seq.shape[0]
    tnorm = np.linspace(0.0, 1.0, t) if t > 1 else np.zeros(1)

    feats: list[float] = []
    channel_std: list[float] = []
    channel_dyn: list[float] = []
    for c in range(NUM_AU):
        col = seq[:, c]
        mean = float(col.mean())
        std = float(col.std())
        cmin = float(col.min())
        cmax = float(col.max())
        slope = float(np.polyfit(tnorm, col, 1)[0]) if t > 1 else 0.0
        dyn = float(np.abs(np.diff(col)).mean()) if t > 1 else 0.0
        feats.extend([mean, std, cmin, cmax, slope, dyn])
        channel_std.append(std)
        channel_dyn.append(dyn)
    feats.append(float(np.mean(channel_std)))   # global expressivity
    feats.append(float(np.mean(channel_dyn)))   # global total motion
    return np.asarray(feats, dtype=np.float64)


# --------------------------------------------------------------------------- #
# Standardiser (fit on train only)
# --------------------------------------------------------------------------- #
class Standardizer:
    """Per-feature z-scoring. Fit over the first axis of a 2D array."""

    def __init__(self) -> None:
        self.mean_: np.ndarray | None = None
        self.std_: np.ndarray | None = None

    def fit(self, x: np.ndarray) -> "Standardizer":
        x = np.asarray(x, dtype=np.float64)
        self.mean_ = x.mean(axis=0)
        std = x.std(axis=0)
        std[std < 1e-8] = 1.0
        self.std_ = std
        return self

    def transform(self, x: np.ndarray) -> np.ndarray:
        if self.mean_ is None or self.std_ is None:
            raise RuntimeError("Standardizer must be fit before transform.")
        return (np.asarray(x, dtype=np.float64) - self.mean_) / self.std_

    def fit_transform(self, x: np.ndarray) -> np.ndarray:
        return self.fit(x).transform(x)

    # -- (de)serialisation for the run/model bundle ----------------------- #
    def state_dict(self) -> dict[str, list[float]]:
        if self.mean_ is None or self.std_ is None:
            raise RuntimeError("Nothing to serialise; fit first.")
        return {"mean": self.mean_.tolist(), "std": self.std_.tolist()}

    @classmethod
    def from_state_dict(cls, state: dict[str, list[float]]) -> "Standardizer":
        obj = cls()
        obj.mean_ = np.asarray(state["mean"], dtype=np.float64)
        obj.std_ = np.asarray(state["std"], dtype=np.float64)
        return obj


def fit_sequence_standardizer(sequences: list[np.ndarray]) -> Standardizer:
    """Fit a per-AU-channel standardiser over all frames of all sequences."""
    stacked = np.concatenate([np.asarray(s, dtype=np.float64) for s in sequences], axis=0)
    return Standardizer().fit(stacked)


def apply_sequence_standardizer(seq: np.ndarray, scaler: Standardizer) -> np.ndarray:
    return scaler.transform(seq).astype(np.float32)
