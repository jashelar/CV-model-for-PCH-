"""Evaluation metrics and operating-point selection.

The headline screening metric here is the **false-positive rate** at a fixed
operating point: a screening tool that cries wolf erodes clinician trust, so
we pick the decision threshold on the *validation* split as the lowest
threshold whose FPR stays within a budget, then report metrics at that same
threshold on the test split.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np


@dataclass
class Metrics:
    threshold: float
    accuracy: float
    precision: float
    recall: float          # sensitivity / TPR
    specificity: float
    f1: float
    roc_auc: float
    fpr: float             # false-positive rate at the threshold
    n: int
    tp: int
    fp: int
    tn: int
    fn: int

    def as_dict(self) -> dict:
        return asdict(self)

    def summary(self) -> str:
        return (
            f"AUC={self.roc_auc:.3f}  acc={self.accuracy:.3f}  "
            f"sens={self.recall:.3f}  spec={self.specificity:.3f}  "
            f"FPR={self.fpr:.3f}  F1={self.f1:.3f}  (thr={self.threshold:.3f}, n={self.n})"
        )


def choose_threshold_for_fpr(
    y_true: np.ndarray, y_score: np.ndarray, target_fpr: float
) -> float:
    """Lowest threshold whose FPR <= ``target_fpr`` on the given data.

    Lowering the threshold raises sensitivity; among thresholds that respect
    the FPR budget we therefore take the smallest, maximising recall.
    """
    y_true = np.asarray(y_true).astype(int)
    y_score = np.asarray(y_score, dtype=float)
    neg = y_score[y_true == 0]
    if neg.size == 0:
        return 0.5
    candidates = np.unique(np.concatenate([y_score, [0.0, 1.0]]))
    best = 1.0
    for thr in np.sort(candidates):
        fpr = float((neg >= thr).mean())
        if fpr <= target_fpr:
            best = float(thr)
            break
    return best


def compute_metrics(
    y_true: np.ndarray, y_score: np.ndarray, threshold: float
) -> Metrics:
    from sklearn.metrics import roc_auc_score

    y_true = np.asarray(y_true).astype(int)
    y_score = np.asarray(y_score, dtype=float)
    y_pred = (y_score >= threshold).astype(int)

    tp = int(((y_pred == 1) & (y_true == 1)).sum())
    fp = int(((y_pred == 1) & (y_true == 0)).sum())
    tn = int(((y_pred == 0) & (y_true == 0)).sum())
    fn = int(((y_pred == 0) & (y_true == 1)).sum())

    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    specificity = tn / (tn + fp) if (tn + fp) else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
    fpr = fp / (fp + tn) if (fp + tn) else 0.0
    accuracy = (tp + tn) / len(y_true) if len(y_true) else 0.0
    try:
        auc = float(roc_auc_score(y_true, y_score)) if len(np.unique(y_true)) > 1 else float("nan")
    except Exception:
        auc = float("nan")

    return Metrics(
        threshold=float(threshold),
        accuracy=accuracy,
        precision=precision,
        recall=recall,
        specificity=specificity,
        f1=f1,
        roc_auc=auc,
        fpr=fpr,
        n=len(y_true),
        tp=tp, fp=fp, tn=tn, fn=fn,
    )
