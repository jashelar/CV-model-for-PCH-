#!/usr/bin/env python3
"""Generate the synthetic demo dataset (AU sequences + manifest).

    python scripts/make_demo_data.py --out data/synthetic --subjects 120

Produces ``data/synthetic/manifest.csv`` and per-clip ``au/*.npy``. The data
is SYNTHETIC and does not represent any real person.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Allow running as a plain script without installing the package.
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ptsd_screening.synthetic import generate_dataset, save_dataset  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", default="data/synthetic")
    parser.add_argument("--subjects", type=int, default=120)
    parser.add_argument("--seed", type=int, default=1409)
    args = parser.parse_args()

    samples = generate_dataset(n_subjects=args.subjects, seed=args.seed)
    manifest = save_dataset(samples, args.out)
    n_pos = sum(s.label for s in samples)
    print(f"Wrote {len(samples)} clips ({n_pos} ptsd_risk / {len(samples) - n_pos} control)")
    print(f"Manifest: {manifest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
