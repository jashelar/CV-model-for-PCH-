#!/usr/bin/env python3
"""End-to-end demo on synthetic data (one command).

    python scripts/run_demo.py            # baseline (no heavy deps)
    python scripts/run_demo.py --model cnn  # requires torch

Generates the synthetic dataset if absent, trains the chosen model and
prints validation/test metrics. Everything here uses SYNTHETIC data.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ptsd_screening.synthetic import generate_dataset, save_dataset  # noqa: E402
from ptsd_screening.train import main as train_main  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", choices=["cnn", "baseline"], default="baseline")
    parser.add_argument("--data", default="data/synthetic")
    parser.add_argument("--subjects", type=int, default=120)
    parser.add_argument("--seed", type=int, default=1409)
    args = parser.parse_args()

    data_dir = Path(args.data)
    manifest = data_dir / "manifest.csv"
    if not manifest.exists():
        print("Generating synthetic dataset...")
        save_dataset(generate_dataset(n_subjects=args.subjects, seed=args.seed), data_dir)

    print(f"Training model='{args.model}' on {manifest}\n")
    results = train_main(
        ["--manifest", str(manifest), "--model", args.model, "--tag", "demo"]
    )

    print("\n================ DEMO RESULTS (SYNTHETIC DATA) ================")
    print(f"model          : {results['model_kind']}")
    print(f"test AUC       : {results['test']['roc_auc']:.3f}")
    print(f"test accuracy  : {results['test']['accuracy']:.3f}")
    print(f"test sensitivity: {results['test']['recall']:.3f}")
    print(f"test FPR       : {results['test']['fpr']:.3f}  "
          f"(budget {results['target_fpr']:.2f}, thr {results['chosen_threshold']:.3f})")
    print("==============================================================")
    print("Reminder: synthetic data; numbers illustrate the pipeline, not clinical performance.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
