#!/usr/bin/env python3
"""Download the MediaPipe FaceLandmarker model bundle.

The Tasks API needs a ``face_landmarker.task`` file. This fetches the
official float16 bundle. Requires network access (the rest of the demo,
which runs on cached/synthetic AU sequences, does not).
"""

from __future__ import annotations

import argparse
import sys
import urllib.request
from pathlib import Path

MODEL_URL = (
    "https://storage.googleapis.com/mediapipe-models/face_landmarker/"
    "face_landmarker/float16/1/face_landmarker.task"
)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", default="models/face_landmarker.task")
    args = parser.parse_args()

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        print(f"Model already present at {out} ({out.stat().st_size} bytes).")
        return 0
    print(f"Downloading FaceLandmarker model -> {out}")
    try:
        urllib.request.urlretrieve(MODEL_URL, out)
    except Exception as exc:
        print(f"Download failed: {exc}", file=sys.stderr)
        print(f"Manually download {MODEL_URL} and save it to {out}.", file=sys.stderr)
        return 1
    print(f"Done ({out.stat().st_size} bytes).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
